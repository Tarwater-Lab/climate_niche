library(tidyverse)
library(jagsUI)
library(latex2exp)

setwd("~/Documents/GitHub/LIMBO/CMR/MGL/CJS_Prad")
load('data_final.RData')

#~~~~~~~~~~~~~~~~~
# Model specifications
#~~~~~~~~~~~~~~~~~
### Parameters to monitor
parameters <- c('mu.phi', 'b', 'gamma', 'beta.p', 'mu.p',
                'mu.phi.species','sigma.phi.species','p','phi',
                'lambda', 'tau', 'beta', 'mu.lambda',
                'eps.phi', 'eps.b','ppp','eps.diet',
                'mu.lambda.time','sigma.lambda.time',
                'mu.species.lambda','sigma.species.lambda',
                'lambda.pred','beta.mu','tau_p','beta.lambda','eps')

apply(s.marray,c(1,3),sum)

### Model specifications
nt <- 5 # Thinning
ni <- 40000 # Iterations
nb <- 20000 # Burn-in
nc <- 3 # Chains

### Model data
jags.data <- list(nT = 48,
                  n.species=nrow(sp.capt), nh=effort3$rel,
                  priors=surv.priors$mu,
                  marr1=marr1, rel1=rel1, 
                  rel.first=colSums(f.star), f=f.star,
                  dpa=climate$dry.precip.a, dpa2=climate$dry.precip.a^2,
                  dta=climate$dry.temp.a, dta2=climate$dry.temp.a^2,
                  wpa=climate$wet.precip.a, wpa2=climate$wet.precip.a^2,
                  dpa.lag=climate$dry.precip.lag, dpa2.lag=climate$dry.precip.lag^2,
                  dta.lag=climate$dry.temp.lag, dta2.lag=climate$dry.temp.lag^2,
                  wpa.lag=climate$wet.precip.lag, wpa2.lag=climate$wet.precip.lag^2,
                  wta=climate$wet.temp.a,wta2=climate$wet.temp.a^2,
                  wta.lag=climate$wet.temp.lag,wta2.lag=climate$wet.temp.lag^2,
                  zeros=rep(0, nrow(sp.capt)),
                  tw=trait.data$temp.width, aw=trait.data$arid_width, 
                  fhr=trait.data$fhr.scale,
                  C_inv=phylo,
                  S=s.marray, R=r.marray, s.rel= apply(s.marray,3, rowSums, na.rm=T), r.rel=apply(r.marray,3, rowSums))


### Initial values
inits <- function(){list(beta.p=0,
                         sigma.species.phi=1)}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
### Run model!
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
start.time <- Sys.time()
m2 <- jags(jags.data, inits, parameters, "models/lambda_climate_noMS_phylo_freeLambda_gen.jags", parallel = T,
           n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb)
end.time <- Sys.time()
run.time = end.time-start.time
run.time

### In case updating is neede
# m2 <- update(m2, n.iter=20000)

### Save file
save.image('SR_climate_noMS_phylo70_RS.RData')

