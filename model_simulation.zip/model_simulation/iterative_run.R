#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Set up
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

library(tidyverse)
library(jagsUI)
library(latex2exp)

setwd("~/Desktop/sim_Apr26")
source('finalCode/dataSim.R') # Data simulation script
source('finalCode/noMS_PradelFull.R') # Model
set.seed(2026)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Set up values for simulation and analysis
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~
# "Truth"
#~~~~~~~~~~~~~~~~
p = seq(0.2,0.4,by=0.1) # Detection probability
n1 = seq(40,100, by=20) # Initial population size
tau = seq(0.7,0.9,by=0.1) # Residency
mu.phi=seq(0.6,0.8,by=0.1) # Survival
b = seq(0.2,0.4,by=0.1) # Recruitment

# Form data frame and name columns
combos <- as.data.frame(expand.grid(p, n1,tau,mu.phi,b))
colnames(combos) <- c('p', 'n1', 'tau','phi','b')

combos$lambda = combos$b + combos$phi # Population growth rate

# combos <- combos[-c(which(combos$lambda < 0.9)),]


### Simulation values
nT = 10 # Number of years to simulate


#~~~~~~~~~~~~~~~~
# Empty data frames/matrixes
#~~~~~~~~~~~~~~~~
### Simulation/"Truth" value combinations
combos$inds <- NA
combos$recaps <- NA
combos$ratio <- NA

### Store results and sum of squared errors
res2 = array(NA, dim=c(nrow(combos), 19, 11)) # Results
sse = matrix(NA,nrow(combos), 5) # SSE




### DIC value
DIC <- NA

#~~~~~~~~~~~~~~~~
# Model specifications
#~~~~~~~~~~~~~~~~
nt <- 5 # Thinning rate
ni <- 40000 # Iterations
nb <- 20000 # Burn-in
nc <- 3 # Chains

### Parameters to save
parameters <- c('mu.phi','mu.p','mu.tau', 'mu.lambda',
                'b', 'eps.phi', 'lambda', 'phi', 'p', 'tau','phi')




### Does the model run recover the true values?
wcri <- as.data.frame(matrix(NA, nrow(combos),6))
colnames(wcri) <- c('phi.w','p.w','tau.w','lambda.w', 'b.w','gamma.w')
res.b <- NULL
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Run iterative analysis
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ii=0
start.time <- Sys.time()

for(ii in (ii+1):nrow(combos)){  
  print(ii)
  
  #~~~~~~~~~~~~~~~~~~~~ 
  # Simulate and prepare data for model
  #~~~~~~~~~~~~~~~~~~~~ 
  dat <- try(dataSim(qlogis(combos$p[ii]), combos$n1[ii], combos$tau[ii],
                 qlogis(combos$phi[ii]), nT,combos$b[ii]))

  if (inherits(dat, "try-error")) {
    next
  }
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Gather data and run model
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  jags.data <- list(marr1 = dat$marr1, rel1=dat$rel1,
                    rel.first=sum(dat$f.star), f=dat$f.star,
                    S=dat$S, R=dat$R, s.rel=dat$s.sum, r.rel=dat$r.sum,
                    nT=nT)
  
  ### Initial values
  inits <- function(){list(mu.phi=qlogis(combos$phi[ii]),mu.p=qlogis(combos$p[ii]),
                           mu.tau=combos$tau[ii],
                           rho=combos$b[ii])}
  ### Run model
  m2 <- try(jags(jags.data, inits=inits, parameters, "jags_models/noMS_3array_PradelFirst_new.jags", parallel = T,
             n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb))
  if (inherits(m2, "try-error")) {
    next
  }
  
  #~~~~~~~~~~~~~
  # Save results
  #~~~~~~~~~~~~~
  ### Model values
  res2[ii,1,] <- summary(m2)[1,] # mu.phi
  res2[ii,2,] <- summary(m2)[2,] # mu.p
  res2[ii,3,] <- summary(m2)[3,] # mu.tau  
  res2[ii,4,] <- summary(m2)[4,] # mu.lambda
  res.b[ii] <- mean(m2$mean$b)
  
  ### Number of individuals and number of recaps
  combos$inds[ii] = nrow(dat$y) # Number of individuals
  combos$recaps[ii] = sum(dat$y[,2:ncol(dat$y)]) # Number of recaps
  combos$ratio[ii] = combos$recaps[ii] / combos$inds[ii] # Ratio of recaps:individuals
  
  ### Sum of squared errors (SSE_)
  sse[ii,1] <- sum((plogis(m2$mean$mu.phi) - combos$phi[ii])^2) # Survival
  sse[ii,2] <- sum((plogis(m2$mean$mu.p) - combos$p[ii])^2) # Detection
  sse[ii,3] <- sum((m2$mean$tau - combos$tau[ii])^2) # Residency
  sse[ii,4] <- sum((mean(m2$mean$b) - combos$b[ii])^2) # Recruitment
  sse[ii,5] <- sum((mean(m2$mean$lambda) - combos$lambda[ii])^2) # Population growth rate
  
  ### Did it recover truth?
  wcri[ii,1] <- (combos$phi[ii] > plogis(m2$q2.5$mu.phi)) & (combos$phi[ii] < plogis(m2$q97.5$mu.phi)) # Survival
  wcri[ii,2] <- (combos$p[ii] > plogis(m2$q2.5$mu.p)) & (combos$p[ii] < plogis(m2$q97.5$mu.p)) # Detection probability 
  wcri[ii,3] <- (combos$tau[ii] > m2$q2.5$tau) & (combos$tau[ii] < m2$q97.5$tau) # Residency
  # wcri[ii,4] <- (combos$lambda[ii] > exp(m2$q2.5$mu.lambda)) & (combos$lambda[ii] < exp(m2$q97.5$mu.lambda)) # Population growth rate
  wcri[ii,4] <- (combos$lambda[ii] > mean(m2$q2.5$lambda)) & (combos$lambda[ii] < mean(m2$q97.5$lambda)) # Population growth rate
  wcri[ii,5] <- (combos$b[ii] > mean(m2$q2.5$b)) & (combos$b[ii] < mean(m2$q97.5$b)) # Recruitment
  wcri[ii,6] <- (combos$gamma[ii] > mean(m2$q2.5$gamma)) & (combos$gamma[ii] < mean(m2$q97.5$gamma)) # Recruitment
  ### DIC
  DIC[ii] <- m2$DIC
  }
end.time <- Sys.time()

end.time-start.time

#save.image('iterative_noMS3arrayFull.RData')


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Examine results
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~
# Did it recover truth?
#~~~~~~~~~~~~

wcri <- as.data.frame(wcri)
colSums(wcri,na.rm=T) / c(length(which(!(is.na(wcri$phi.w)))),
                          length(which(!(is.na(wcri$p.w)))),
                          length(which(!(is.na(wcri$tau.w)))),
                          length(which(!(is.na(wcri$lambda.w)))),
                          length(which(!(is.na(wcri$b.w)))))

#~~~~~~~~~~~~
# Trace plots
# This is for one iteration, please check these for several different parameter combinations
#~~~~~~~~~~~~
### Survival
plot(m2$sims.list$mu.phi, type='l')
abline(h=qlogis(combos$phi[ii]),col='red')

### Detection
plot(m2$sims.list$mu.p, type='l')
abline(h=qlogis(combos$p[ii]),col='red')

### Recruitment
par(mfrow=c(3,3))
for(t in 1:(nT-1)){
  plot(m2$sims.list$b[,t], type='l', main=paste('Year = ', t))
  abline(h=combos$b[ii],col='red')
}
par(mfrow=c(1,1))

### Population growth rate
par(mfrow=c(3,3))
for(t in 1:(nT-1)){
  plot(m2$sims.list$lambda[,t], type='l', main=paste('Year = ', t))
  abline(h=combos$lambda[ii],col='red')
}
par(mfrow=c(1,1))

### Residency
plot(m2$sims.list$tau, type='l')
abline(h=combos$tau[ii],col='red')


#~~~~~~~~~~~~
# Residency is generally the most difficult to recover parameter
# Are there certain areas of parameter space that are worse?
#~~~~~~~~~~~~
cw <- cbind(combos,wcri)
cw %>%
  filter(!is.na(tau.w)) %>%
  ggplot(aes(y=phi,x=tau.w)) +
  geom_violin()

cw %>%
  filter(!is.na(tau.w)) %>%
  ggplot(aes(y=p,x=tau.w)) +
  geom_violin()

cw %>%
  filter(!is.na(tau.w)) %>%
  ggplot(aes(y=tau,x=tau.w)) +
  geom_violin()

cw %>%
  filter(!is.na(tau.w)) %>%
  ggplot(aes(y=b,x=tau.w)) +
  geom_violin()

cw %>%
  filter(!is.na(tau.w)) %>%
  ggplot(aes(y=n1,x=tau.w)) +
  geom_violin()


#~~~~~~~~~~~~
# Correlations between parameters
#~~~~~~~~~~~~

mus <- data.frame(phi=plogis(res2[,1,5]),
                  p=plogis(res2[,2,5]),
                  tau=res2[,3,5],
                  lambda=exp(res2[,4,5]),
                  b=res.b,
                  inds=combos$inds)


### Survival ~ Residency
ggplot(mus,aes(x=tau,y=phi,color=inds)) +
  geom_point() +
  xlab("Residency") +
  ylab("Survival") 

### Detection ~ Residency
ggplot(mus,aes(x=tau,y=p,color=inds)) +
  geom_point() +
  xlab("Residency") +
  ylab("Detection") 

### Recruitment ~ Residency
ggplot(mus,aes(x=tau,y=b,color=inds)) +
  geom_point() +
  xlab("Residency") +
  ylab("Recruitment") 

### Survival ~ Detection
ggplot(mus,aes(x=phi,y=p,color=inds)) +
  geom_point() +
  xlab("Survival") +
  ylab("Detection") 

### Recruitment ~ Residency
ggplot(mus,aes(x=p,y=b,color=inds)) +
  geom_point() +
  xlab("Detection") +
  ylab("Recruitment") 

### Recruitment ~ Survival
ggplot(mus,aes(x=phi,y=b,color=inds)) +
  geom_point() +
  xlab("Survival") +
  ylab("Recruitment") 

### Recruitment ~ Detection
ggplot(mus,aes(x=p,y=b,color=inds)) +
  geom_point() +
  xlab("Detection") +
  ylab("Recruitment") 


#~~~~~~~~~~~~
# SSE
#~~~~~~~~~~~~
### Set up the data frame
sse <- as.data.frame(sse)
colnames(sse) <- c('phi.sse','p.sse','tau.sse','b.sse','lambda.sse')
sse_final <- cbind(combos, sse)
colnames(sse_final)[10:14] <- c('phi.est', 'p.est','tau.est','b.est','lambda.est')
### Get cumulative SSE
sse_final$sum.sse <- rowSums(sse_final[,10:14],na.rm=T)
sse_final$sum.sse[which(sse_final$sum.sse>1)] = NA

### SSE ~ Ratio (Recaps:Individuals captured)
ggplot(sse_final, aes(x=ratio,y=sum.sse, color=inds)) +
  geom_point() +
  labs(title='Recaps:Individuals ~  Total SSE',
       x='# Recaptures:# Individuals',
       y='Total SSE') +
  theme_classic()

### Ratio ~ Residency SSE
ggplot(sse_final, aes(x=ratio,y=tau.est)) +
  geom_point() +
  labs(title='Recaps:Individuals ~ Residency SSE',
       x='# Recaptures:# Individuals',
       y='Residency SSE') +
  theme_classic()

### Ratio ~ Residency SSE
ggplot(sse_final, aes(x=ratio,y=phi.est)) +
  geom_point() +
  labs(title='Recaps:Individuals ~ Survival SSE',
       x='# Recaptures:# Individuals',
       y='Survival SSE') +
  theme_classic()


ggplot(sse_final, aes(x=ratio,y=b,color=inds)) +
  geom_point() +
  labs(title='Recaps:Individuals ~ Recruitment SSE',
       x='# Recaptures:# Individuals',
       y='Recruitment SSE') +
  theme_classic()



#~~~~~~~~~~~~
# How does SSE change with different truth values?
### Explore parameter space for areas of bias
#~~~~~~~~~~~~
#~~~~~~~~~
# Population growth rate
#~~~~~~~~~
### N1
ggplot(sse_final, aes(x=n1,y=lambda.est)) +
  geom_point() +
  labs(title='N1 ~ Population growth SSE')
### Residency
ggplot(sse_final, aes(x=tau,y=lambda.est)) +
  geom_point() +
  labs(title='Residency ~ Population growth SSE')
### Detection
ggplot(sse_final, aes(x=p,y=lambda.est)) +
  geom_point() +
  labs(title='p ~ Population growth SSE')

#~~~~~~~~~
# Detection
#~~~~~~~~~
### N1
ggplot(sse_final, aes(x=n1,y=p.est)) +
  geom_point() +
  labs(title='N1 ~ Detection SSE')
### Residency
ggplot(sse_final, aes(x=tau,y=p.est)) +
  geom_point() +
  labs(title='Residency ~ Detection SSE')
### Detection
ggplot(sse_final, aes(x=p,y=p.est)) +
  geom_point() +
  labs(title='p ~ Detection SSE')

#~~~~~~~~~
# Residency
#~~~~~~~~~
### N1
ggplot(sse_final, aes(x=n1,y=tau.est)) +
  geom_point() +
  labs(title='N1 ~ Residency SSE')
### Residency
ggplot(sse_final, aes(x=tau,y=tau.est)) +
  geom_point() +
  labs(title='Residency ~ Residency SSE')
### Detection
ggplot(sse_final, aes(x=p,y=tau.est)) +
  geom_point() +
  labs(title='p ~ Residency SSE')

#~~~~~~~~~
# Survival
#~~~~~~~~~
### N1
ggplot(sse_final, aes(x=n1,y=phi)) +
  geom_point() +
  labs(title='N1 ~ Survival SSE')
### Residency
ggplot(sse_final, aes(x=tau,y=phi)) +
  geom_point() +
  labs(title='Residency ~ Survival SSE')
### Detection
ggplot(sse_final, aes(x=p,y=phi)) +
  geom_point() +
  labs(title='p ~ Survival SSE')

#~~~~~~~~~
# Recruitment
#~~~~~~~~~
### N1
ggplot(sse_final, aes(x=n1,y=b)) +
  geom_point() +
  labs(title='N1 ~ Recruitment SSE')
### Residency
ggplot(sse_final, aes(x=tau,y=b)) +
  geom_point() +
  labs(title='Residency ~ Recruitment SSE')
### Detection
ggplot(sse_final, aes(x=p,y=b)) +
  geom_point() +
  labs(title='p ~ Recruitment SSE')




#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Detection and transiency SSE
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sse_p_tau <- as.data.frame(expand.grid(p,tau))
colnames(sse_p_tau) <- c('p','tau')

sse.means <- sse_final %>%
  group_by(p, tau) %>%
  select(phi.est:lambda.est) %>%
  summarise(phi_sse=mean(phi.est,na.rm=T),
            tau_sse=mean(tau.est,na.rm=T),
            p_sse=mean(p.est,na.rm=T),
            b_sse=mean(b.est,na.rm=T),
            lambda_sse=mean(lambda.est,na.rm=T))

sse_p_tau <- left_join(sse_p_tau, sse.means)


### Survival
ggplot(sse_p_tau, aes(p, tau, fill=phi_sse)) +
  geom_tile() +
  labs(title='Survival SSE') +
  theme_classic()
### Detection
ggplot(sse_p_tau, aes(p, tau, fill=p_sse)) +
  geom_tile() +
  labs(title='Detection SSE') +
  theme_classic()
### Transiency
ggplot(sse_p_tau, aes(p, tau, fill=tau_sse)) +
  geom_tile() +
  labs(title='Transiency SSE') +
  theme_classic()
### Lambda
ggplot(sse_p_tau, aes(p, tau, fill=lambda_sse)) +
  geom_tile() +
  labs(title='Population growth SSE') +
  theme_classic()
### Recruitment
ggplot(sse_p_tau, aes(p, tau, fill=b_sse)) +
  geom_tile() +
  labs(title='Recruitment SSE') +
  theme_classic()

sse_p_tau <- pivot_longer(sse_p_tau, cols=phi_sse:lambda_sse)
colnames(sse_p_tau)[3:4] <- c('Parameter', 'SSE')

sse_p_tau %>%
  filter(SSE < 1) %>%
ggplot(aes(p, tau, fill=SSE)) +
  geom_tile() +
  facet_wrap(vars(Parameter)) +
  labs(title='SSE of Key Variables', subtitle='Detection ~ Transiency') +
  theme_classic()




#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Population size and detection SSE
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sse.n1.p <- as.data.frame(expand.grid(p,n1))
colnames(sse.n1.p) <- c('p','n1')

sse.means <- sse_final %>%
  group_by(p, n1) %>%
  select(phi.est:lambda.est) %>%
  summarise(phi_sse=mean(phi.est,na.rm=T),
            tau_sse=mean(tau.est,na.rm=T),
            p_sse=mean(p.est,na.rm=T),
            b_sse=mean(b.est,na.rm=T),
            lambda_sse=mean(lambda.est,na.rm=T))

sse.n1.p <- left_join(sse.n1.p, sse.means)
sse.n1.p <- pivot_longer(sse.n1.p, cols=phi_sse:lambda_sse)
colnames(sse.n1.p)[3:4] <- c('Parameter', 'SSE')

sse.n1.p %>%
  filter(SSE < 1) %>%
ggplot(aes(p, n1, fill=SSE)) +
  geom_tile() +
  facet_wrap(vars(Parameter)) +
  labs(title='SSE of Key Variables', subtitle='Detection ~ N1') +
  theme_classic()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Population size and transiency SSE
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sse.n1.t <- as.data.frame(expand.grid(tau,n1))
colnames(sse.n1.t) <- c('tau','n1')

sse.means <- sse_final %>%
  group_by(tau, n1) %>%
  select(phi.est:lambda.est) %>%
  summarise(phi_sse=mean(phi.est,na.rm=T),
            tau_sse=mean(tau.est,na.rm=T),
            p_sse=mean(p.est,na.rm=T),
            b_sse=mean(b.est,na.rm=T),
            lambda_sse=mean(lambda.est,na.rm=T))

sse.n1.t <- left_join(sse.n1.t, sse.means)
sse.n1.t <- pivot_longer(sse.n1.t, cols=phi_sse:lambda_sse)
colnames(sse.n1.t)[3:4] <- c('Parameter', 'SSE')

sse.n1.t %>%
  filter(SSE < 0.75) %>%
ggplot(aes(tau, n1, fill=SSE)) +
  geom_tile() +
  facet_wrap(vars(Parameter)) +
  labs(title='SSE of Key Variables', subtitle='Transiency ~ N1') +
  theme_classic()
