
dataSim <- function(mu.p, n1, tau, mu.phi, nT, b){
  
  # Simulate noise for survival
  w = rnorm(nT)
  beta.phi = 0.2
  
  # Simulate noise for detection probability
  f = rnorm(nT)
  beta.p = -0.2
  
  # Survival vector
  phi = plogis(mu.phi + beta.phi*w)
  # Detection probability vector
  p = plogis(mu.p + beta.p*f)
  
  # Initial latent state matrix (z)
  z <- matrix(NA, n1, (nT+1))
  z[,1] <- 1
  
  # x: Residency vector (1: resident, 0: transient)
  x <- rbinom(n1, 1, tau)
  
  # Recruit (r) and population size (n) vectors
  r <- NULL
  r.all <- NULL
  n <- NULL
  n[1] <- n1
  
  # Create vectors to hold the resident population
  xNew <- vector(mode='list', length=nT+1)
  xNew[[1]] <- x
  n.real <- sum(x)
  r <- round(n.real*b)
  
  # Year 2:nT
  for (t in 2:(nT+1)){
    z[,t] <- rbinom(nrow(z), z[,t-1] * x, phi[t-1]) # Capture history for all individuals
    #r[t-1] <- round(n.real[t-1] * b) # Only residents can recruit new individuals
    # xNew[[t]] <- rbinom(r[t-1], 1, tau) # Of those recruits
    # zNew <- matrix(rep(c(rep(NA,t-1), 1, rep(NA,(nT+1)-t)), r[t-1]),
    #                nrow = r[t-1],
    #                byrow = T)
    xNew[[t]] <- c(rep(1, times=r[t-1]),rep(0,round(n.real[t-1] * (1-tau))))
    zNew <- matrix(rep(c(rep(NA,t-1), 1, rep(NA,(nT+1)-t)), length(xNew[[t]])),
                   nrow = length(xNew[[t]]),
                   byrow = T)

    z <- rbind(z, zNew)
    x <- append(x, xNew[[t]])
    n[t] <- sum(z[,t], na.rm = T)
    #n.real[t] <- sum(sapply(xNew[1:t],sum))
    n.real[t] <- sum(z[,t-1]*x,na.rm=T)
    r[t] <- round(n.real[t] * b)
  }
  
  z <- z[,2:(nT+1)]
  # plot(n, type = 'b', ylab = 'Abundance (n)', xlab = 'Time (t)', cex.lab = 2,
  #      las = 1, cex = 1.5)
  
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Data simulation
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # 
  # y: capture history
  # p: detection probability
  # f: first encounter
  # 
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  y <- matrix(NA, nrow(z), ncol(z))
  for (i in 1:nrow(y)){
    for (t in 1:ncol(y)){
      y[i,t] <- ifelse(!is.na(z[i,t]),
                       rbinom(1, z[i,t], p),
                       0)
    }
  } 
  
  all0 <- apply(y, 1, function(x) all(x == 0))
  y <- y[-c(which(all0 == TRUE)),]
  # find first capture and subset to encountered individuals
  getF <- function(x){min(which(x == 1))}
  f <- apply(y, 1, getF)
  y <- subset(y, f != Inf)
  f <- f[f != Inf]
  
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # format data for model 1
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  y1 <- y
  marr1 <- IPMbook::marray(y1)
  rel1 <- rowSums(marr1)
  rm(y1)
  
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # format data for model 2
  # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  y2 <- y
  for (i in 1:nrow(y2)){
    if (f[i] < nT){
      for (t in (f[i]+1):nT){
        if (y2[i,t] == 1){
          y2[i,t] <- 2
        }
      }
    }
  }
  marr2 <- IPMbook::marray(y2, unobs = 1)
  rel2 <- rowSums(marr2)
  
  f.star = as.vector(table(f))
  
  f.star = rep(0, nT)
  for(t in 1:nT){
    f.star[t] = length(which(f == t))
  }
  
  lambda = b*tau + phi
  
  get.last <- function(x){
    max(which(x == 1))
  }
  l <- apply(y,1,get.last)
  z2 <- matrix(NA,nrow(y),nT)
  for(i in 1:nrow(y)){
    if(f[i] < nT){
      z2[i,(f[i]):l[i]] <- 1  
    }
  }
  
  res <- rep(NA,nrow(y))
  res[which(rowSums(z2,na.rm=T)>1)] <- 1
  
  # Detect those whose first recapture is in the same year
  get.second <- function(y.play){
    want <- which(y.play == 1)[2]
    return(want)
  }
  sec <- apply(y,1,get.second)
  
  # Set up for the for loop
  first.caps = NA
  second.caps = NA
  for(t in 1:nT){
    first.caps <- which(f == t) # Which individuals should we be checking for a second capture the same year?
    second.caps <- rbinom(length(first.caps),1,p[t]) # Coin toss if we captured them again in the same year
    want <- which(second.caps != 0) # Which did we actually capture again in the same year?

    sec[first.caps[want]] <- t # Designate that time period as their second capture
  }
  
  # Determine which capture event for individuals it is
  y.recap <- y
  for(i in 1:nrow(y)){
    # Which capture event for each individual is it?
    y.recap[i,] <- cumsum(y[i,])*y[i,] # ex. 0100101 --> 0100203
    if(!is.na(sec[i]) & sec[i] == f[i]){ 
      # Was the individual captured twice the year it was first captured?
      y.recap[i,] <- (cumsum(y[i,])+1)*y[i,] # ex. 0100101 --> 0200304        
    } #if
  } #i
  
  #~~~~~~~~~~~~~~~~~~~~~
  # Make S
  #~~~~~~~~~~~~~~~~~~~~~
  # s.temp <- y.recap
  # ### Remove all occasions that aren't the first and second capture
  # s.temp[which(s.temp > 2)] <- 0
  # s.temp[which(s.temp > 0)] <- 1
  # 
  # # ### Remove individuals caught fewer than 2 times
  # # Caught Less than to twice (2)
  # cl2 <- apply(s.temp, 1, function(x) all(x == 0))
  # s.temp <- s.temp[which(cl2 == F),]
  
  ### Get second capture m-array
  s.marray <- matrix(0, nT, nT+1)
  for(t in 1:nT){
    # Which individuals were first captured in a given year
    want.inds <- which(f == t)
    # How many individuals were never recaptured?
    s.marray[t,nT+1] <- length(which(is.na(sec[want.inds])))

    for(j in t:nT){
      # How many individuals were caught for the second time in a given year?
      s.marray[t,j] <- length(which(sec[want.inds] == j))
    } #j
  } #t
  
  #~~~~~~~~~~~~~~~~~~~~~
  # Make R
  #~~~~~~~~~~~~~~~~~~~~~
  ### Get capture history for individuals captured more than twice
  r.temp <- y.recap
  r.temp[which(r.temp < 2)] <- 0
  r.temp[which(r.temp > 0)] <- 1

  # Caught Less than or eQual to twice (2)
  cleq2 <- apply(r.temp, 1, function(x) all(x == 0))
  r.temp <- r.temp[which(cleq2 == F),]

  ### Get m-array for individuals captured more than twice
  r.marray <- IPMbook::marray(r.temp)
  
  
  return(list(y=y, nT=nT, f.star=f.star, f=f, marr1=marr1, marr2=marr2, y2=y2, 
         rel1=rel1,rel2=rel2,phi=phi,tau=tau,p=p,b=r,b=b,mu.phi=mu.phi, 
         n=n,n.real=n.real,mu.p=mu.p,lambda=lambda,z=z2,res=res,S=s.marray,R=r.marray,
         s.sum=rowSums(s.marray),r.sum=rowSums(r.marray),y.recap=y.recap))
}
