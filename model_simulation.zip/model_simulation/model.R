sink("noMS_3array_PradelFull.jags")
cat("
    model {

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # CJS parameters
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~
    # Priors
    # ~~~~~~~~~~~~~~~
    mu.phi ~ dnorm(1,1) # Survival
    mu.p ~ dnorm(1,1) # Detection
    tau ~ dbeta(1,1) # Residency
    mu.lambda ~ dnorm(0,0.001) # Population growth rate
    
    ### Random temporal effects
    for(t in 1:(nT-1)){
      eps.phi[t] ~ dnorm(0,1) # Survival
      eps.p[t] ~ dnorm(0,1) # Detection
      eps.lambda[t] ~ dnorm(0,0.001) # Population growth rate
    }
    eps.p[nT] ~ dnorm(0,1) # Last year of detection
    
    # ~~~~~~~~~~~~~~~
    # Parameters
    # ~~~~~~~~~~~~~~~
    for (t in 1:(nT-1)){
      logit(phi[t]) = (mu.phi + eps.phi[t])
    }
    for(t in 1:nT){
      logit(p[t]) = (mu.p + eps.p[t])
    }
    
    # ~~~~~~~~~~~~~~~
    # Data
    # ~~~~~~~~~~~~~~~
    for (t in 1:nT){
      S[t,1:(nT+1)] ~ dmulti(pi[t,1:(nT+1)], s.rel[t]) # Second capture
    }
    for (t in 1:(nT-1)){
      R[t,1:nT] ~ dmulti(pi.r[t,1:nT], r.rel[t]) # Third+ capture
    }
  
  # ~~~~~~~~~~~~~~~
  # Likelihood
  # ~~~~~~~~~~~~~~~
  # 0s for below the diagonal
    for (t in 2:nT){
      for (j in 1:(t-1)){
        pi[t,j] <- 0
      } #j
    } #t
    for (t in 2:(nT-1)){
      for (j in 1:(t-1)){
        pi.r[t,j] <- 0
      } #j
    } #
    
    #~~~~~~~~~
    # The second capture
    #~~~~~~~~~
    for(t in 1:(nT-1)){
      # If it was caught in the same year as capture, it's detected and a resident
      pi[t,t] = p[t] * tau
      
      phi_eff[t] <- tau * phi[t]   # Did it survive and is it a resident?
      # If it was caught in the next year, it survived, was detected, and is a resident
      pi[t,t+1] <- phi_eff[t]*p[t+1]
    
      
      for(j in (t+2):nT){
          # If it was caught in not the next year, probabilities include residency, non-detection in years t:(j-1), survival, and detection in year t 
          pi[t,j] <- phi_eff[t] * prod(1-p[(t+1):(j-1)]) * prod(phi[(t+1):(j-1)]) * p[j]
      } #j
      
      # What's the probability of never being seen again?
      pi[t,nT+1] = 1 - sum(pi[t,1:nT])
    } #t

    # Final year does not need a survival parameter
    pi[nT,nT] = tau * p[nT]
    # What's the probability of never being seen again?
    pi[nT,nT+1] = 1 - sum(pi[nT,1:nT])
    
  
    #~~~~~~~~~
    # Beyond the second capture
    ### Residency has already been accounted
    #~~~~~~~~~
    for(t in 1:(nT-1)){
      # It survived and was dectected teh next year
      pi.r[t,t] = phi[t] * p[t+1] 
      
      for(j in (t+1):(nT-1)){
        # If it was caught in not the next year, probabilities include non-detection in years t:(j-1), survival, and detection in year t 
        pi.r[t,j] = prod(1-p[(t+1):j]) * prod(phi[t:j]) * p[j+1]
      } #j
      # What's the probability of never being seen again?
      pi.r[t,nT] = 1 - sum(pi.r[t,1:(nT-1)])
    } #t
    
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Pradel
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # First capture occasion
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # It needed to either be (1) detected, present before the capture occasion, and a resident or (2) detected and not a resident
    f.prime[1] <- (p[1]*xi[1]*tau) + (p[1]*(1-tau))
    for(t in 2:nT){
      # Subsequent years include population growth rates to account for why more or less individuals were captured for the first time
      f.prime[t] <- (prod(lambda[1:(t-1)])*p[t]*xi[t]*tau) + (p[t]*(1-tau))
    }
    
    for(t in 1:nT){
      # Probability an individual was captured for the first time in a given year
      f.star[t] <- f.prime[t] / sum(f.prime)
      # Likelihood of first capture
      f[t] ~ dbin(f.star[t], rel.first)
    } # t

    # Probability an individual was present before the capture occasion, but not detected in previous years
    xi[1] <- 1
    for(t in 2:nT){
      xi[t] <- ((1-gamma[t-1]) + (gamma[t-1] * (1-p[t-1]) * xi[t-1]))
    } # t
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Subsequent capture occasions
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for(t in 1:(nT-1)){
      # Likelihood
      marr1[t,] ~ dmulti(pi2[t,], rel1[t])
    }

    for(t in 1:(nT-1)){
      # Probabilty of an individual being present and detected
      pi2[t,t] = gamma[t]*p[t]*xi[t]

      for(j in (t+1):(nT-1)){
        # If it was caught in not the next year, probabilities include non-detection in years t:(j-1), survival, and detection in year t 
        pi2[t,j] = prod(1-p[(t+1):j]) * prod(gamma[(t+1):(j+1)]) * p[j+1] * xi[j]
      }
      # Leftover probabilities
      pi2[t,nT] = 1 - sum(pi2[t,1:(nT-1)])
    }
    
    # Below the diagonal is 0
    for (t in 2:(nT-1)){
      for (j in 1:(t-1)){
        pi2[t,j] <- 0
      } #j
    } #t

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Pradel parameters
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Seniority in t=1
    gamma[1] <- 1
    
    for(t in 1:(nT-1)){
      # Population growth rate
      lambda[t] <- exp(mu.lambda + eps.lambda[t])

      # Seniority in t=2, ..., nT
      gamma[t+1] <- phi[t]/lambda[t]
      
      # Recruitment
      b[t] <- lambda[t] - phi[t]
    } # t

    
    } # model
    ",fill = TRUE)
sink()


