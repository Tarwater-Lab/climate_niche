sink("models/lambda_add_noMS_phylo.jags")
cat("
    model {

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # CJS parameters
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ~~~~~~~~~~~~~~~
    # Priors
    # ~~~~~~~~~~~~~~~
    
    ### Survival temporal random effect
    sigma.phi.time ~ dunif(0, 8)
    tau.phi.time = pow(sigma.phi.time,-2)
    
    ### Survival species random effect (non-phylogenetic)
    sigma.species.phi ~ dunif(0, 8)
    tau.species.phi = pow(sigma.species.phi,-2)
    
    ### Effort beta.lambda coefficient for detection probability
    beta.p ~ dnorm(0,1)
    
    ### Regression coefficients for population growth rates
    for(h in 1:11){
      beta.lambda[h] ~ dnorm(0, 0.001)
    } #h
    
    ### Phylogenetic random effect for population growth rate
    tau_p ~ dgamma(0.001, 0.001)   # phylogenetic precision
    eps ~ dmnorm(zeros, tau_p * C_inv)
    
    ### Priors for species-specific parameter means
    for(sp in 1:n.species){
      ### Mean population growth rate
     # mu.lambda[sp] ~ dnorm(0, tau.species.lambda)
      ### Mean survival
      mu.phi[sp] ~ dnorm(priors[sp], tau.species.phi)
      ### Mean detection 
      mu.p[sp] ~ dnorm(0, 1/2.25)
      ### Residency
      tau.mu[sp] ~ dnorm(0, 1/2.25)
    }

    
    for(sp in 1:n.species){

      for(t in 1:nT){
        ### Time- and species-specific detection probability
        logit(p[t,sp]) <- mu.p[sp] + beta.p*nh[t]
      } # t
      
      ### Residency probability
      logit(tau[sp]) = tau.mu[sp]
      
      for (t in 1:(nT-1)){
        eps.phi[sp,t] ~ dnorm(0, tau.phi.time)
        
        logit(phi[t,sp]) = mu.phi[sp] + eps.phi[sp,t]
      } # t
    } # sp
    
    # ~~~~~~~~~~~~~~~
    # Data
    # ~~~~~~~~~~~~~~~
    for(sp in 1:n.species){
      for (t in 1:nT){
        ### Second capture
        S[t,1:(nT+1),sp] ~ dmulti(pi[t,1:(nT+1),sp], s.rel[t,sp])
      } # t
      for (t in 1:(nT-1)){
        ### Third+ capture
        R[t,1:nT,sp] ~ dmulti(pi.r[t,1:nT,sp], r.rel[t,sp])
      } # t
  
    # ~~~~~~~~~~~~~~~
    # Likelihood
    # ~~~~~~~~~~~~~~~
    # 0s for below the diagonal
      for (t in 2:nT){
        for (j in 1:(t-1)){
          pi[t,j,sp] <- 0 # Second capture
        } #j
      } #t
      for (t in 2:(nT-1)){
        for (j in 1:(t-1)){
          pi.r[t,j,sp] <- 0 # Third+ capture
        } #j
      } #
    
    #~~~~~~~~~
    # The second capture
    #~~~~~~~~~
    for(t in 1:(nT-1)){
      # If it was caught in the same year as capture, it's detected and a resident
      pi[t,t,sp] = p[t,sp] * tau[sp]
      
      phi_eff[t,sp] <- tau[sp] * phi[t,sp]   # Did it survive and is it a resident?
      pi[t,t+1,sp] <- phi_eff[t,sp]*p[t+1,sp]
    
    # If it was caught in the next year, it survived, was detected, and is a resident
      for(j in (t+2):nT){
          pi[t,j,sp] <- phi_eff[t,sp] * prod(1-p[(t+1):(j-1),sp]) * prod(phi[(t+1):(j-1),sp]) * p[j,sp]
      } #j
      # Probability of never being seen again?
      pi[t,nT+1,sp] = 1 - sum(pi[t,1:nT,sp])
    } #t
    
    # Final year does not need a survival parameter
    pi[nT,nT,sp] = tau[sp] * p[nT,sp]
    pi[nT,nT+1,sp] = 1 - sum(pi[nT,1:nT,sp])
    
  
    #~~~~~~~~~
    # Beyond the second capture
    ### Residency has already been accounted for
    #~~~~~~~~~
    for(t in 1:(nT-1)){
      # It survived and was dectected the next year
      pi.r[t,t,sp] = phi[t,sp] * p[t+1,sp]
      
      for(j in (t+1):(nT-1)){
        # If it was caught in not the next year, probabilities include non-detection in years t:(j-1), survival, and detection in year t 
        pi.r[t,j,sp] = prod(1-p[(t+1):j,sp]) * prod(phi[t:j,sp]) * p[j+1,sp] 
      } #j
      # What's the probability of never being seen again?
      pi.r[t,nT,sp] = 1 - sum(pi.r[t,1:(nT-1),sp])
    } #t
    } #sp
   

    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Pradel
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for(sp in 1:n.species){    
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Pradel parameters
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Seniority in t=1
      gamma[1,sp] = 1
      for(t in 1:(nT-1)){
        # Seniority in t=2, ..., nT
        gamma[t+1, sp] <- phi[t,sp] / lambda[t,sp]
        
        # Recruitment
        b[t,sp] <- lambda[t,sp] - phi[t,sp]
        
        # Population growth rate
        log(lambda[t,sp]) <- eps[sp] + 
                              fhr[sp]*beta.lambda[1] + tw[sp]*beta.lambda[2] + aw[sp]*beta.lambda[3] + 
                              dta[t]*beta.lambda[4] + dta2[t]*beta.lambda[5] +
                              wta[t]*beta.lambda[6] + wta2[t]*beta.lambda[7] +
                              wpa[t]*beta.lambda[8] + wpa2[t]*beta.lambda[9] +
                              dpa[t]*beta.lambda[10] + dpa2[t]*beta.lambda[11] #+ eps[sp]
      } #t
    } #sp
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # First capture occasion
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for(sp in 1:n.species){
      # It needed to either be (1) detected, present before the capture occasion, and a resident or (2) detected and not a resident
      f.prime[1,sp] <- (p[1,sp]*xi[1,sp]* tau[sp]) + (p[1,sp]*(1 - tau[sp]))
      for(t in 2:nT){
        # Subsequent years include population growth rates to account for why more or less individuals were captured for the first time
        f.prime[t,sp] <- (prod(lambda[1:(t-1),sp])*p[t,sp]*xi[t,sp]* tau[sp]) + (p[t,sp]*(1 - tau[sp]))
      } #t
  
      for(t in 1:nT){
        # Probability an individual was captured for the first time in a given year
        f.star[t,sp] <- f.prime[t,sp] / sum(f.prime[,sp])
      } #t
  
      for(t in 1:nT){
        # Likelihood of first capture
        f[t,sp] ~ dbin(f.star[t,sp], rel.first[sp])
      } #t
    

      # Probability an individual was present before the capture occasion, but not detected in previous years
      xi[1,sp] <- 1
      for(t in 2:nT){
        xi[t,sp] <- (1-gamma[t-1,sp]) + (gamma[t-1,sp] * (1-p[t-1,sp]) * xi[t-1,sp])
      } #t

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Subsequent capture occasions
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for(t in 1:(nT-1)){
      # Likelihood
      marr1[t,,sp] ~ dmulti(pi2[t,,sp], rel1[t,sp])
    } #t

    for(t in 1:(nT-1)){
      # Probabilty of an individual being present and detected
      pi2[t,t,sp] = gamma[t,sp]*p[t,sp] #* (1-tau[sp])

      for(j in (t+1):(nT-1)){
        # If it was caught in not the next year, probabilities include non-detection in years t:(j-1), survival, and detection in year t 
        pi2[t,j,sp] = prod(1-p[(t+1):j,sp]) * prod(gamma[(t+1):(j+1),sp]) * p[j+1,sp] #* (1-tau[sp])
      } #j
      # Leftover probabilities
      pi2[t,nT,sp] = 1 - sum(pi2[t,1:(nT-1),sp])
    } #t

    # Below the diagonal is 0
    for (t in 2:(nT-1)){
      for (j in 1:(t-1)){
        pi2[t,j,sp] <- 0
      } #j
    } #t

    } #sp
} #model
    ",fill = TRUE)
sink()


